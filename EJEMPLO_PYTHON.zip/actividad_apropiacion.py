"""
#cajero automatico
cuenta ="el numero de la cuenta"
numero_cuenta = 30204567

numero_clave ="el numero de clave "
clave = 2010

saldo ="el saldo de la cuenta"
saldo_cuenta = 100000

retiro ="la cantidad retirada"
monto_retiro = 50000
saldo_restante= saldo_cuenta - monto_retiro

print(cuenta)
print(numero_cuenta)
print(numero_clave)
print(clave)
print(saldo)
print(saldo_cuenta)
print(retiro)
print(monto_retiro)
"""


"""
#usar un chat
nombre = "El nombre de el usuario"
contacto = "Valeria sierra"

Fecha_mensaje = "El dia de el mensaje"
fecha = "15/08/23"

Hora_mensaje = "la hora que se envio"
hora = "11:20"

mensaje_enviado = "Mensaje que se envio"
mensaje = "Hola,bienvenidos"

estado ="el estado de conexion"
conexion = "en linea"

print(nombre)
print(contacto)
print(Fecha_mensaje)
print(fecha)
print(Hora_mensaje)
print(hora)
print(mensaje_enviado)
print(mensaje)
"""


"""
#pagar con tarjeta de credito
nombre = "nombre del usuario"
nombre_cliente = "valeria sierra"

valor = "valor producto"
valor_pagado = 25000

N_tarjeta = "ingresa el numero de tarjeta"
numero_tarjeta = "2010003345"

saldo_disponible = "el saldo disponible"
saldo = 200000

saldo_restante = "el saldo restante del pago"
resta = saldo - valor_pagado

print(nombre)
print(nombre_cliente)
print(valor)
print(valor_pagado)
print(N_tarjeta)
print(numero_tarjeta)
print(saldo_disponible)
print(saldo)
print(saldo_restante)
print(resta)
"""
"""
#lavar la ropa
tipo_lavado = "forma de lavar la ropa"
lavado = "lavadora"
print(tipo_lavado)
print(lavado)


ropa = "ropa por lavar"
cantidad_ropa = 5
print(ropa)
print(cantidad_ropa)

tiempo = "tiempo de lavado"
tiempo_estipulado = "30 minutos"
print(tiempo)
print(tiempo_estipulado)

detergente_usado = "tipo de detergente"
detergente ="suavitel"
print(detergente_usado)
print(detergente)

cantidad_agua = "cantidad que se va a usar"
agua = 20.0
print(cantidad_agua)
print(agua)
"""
#hablar por telefono

medio_llamada = "por que medio se hara la llamada"
dispositivo = "celular"

telefono = "numero del telefono"
telefono_persona = "3148510779"

saldo_celular = "saldo disponible"
saldo = "10000"

disponibilidad = "disponibilidad de la persona"
disponible_contacto = "Disponible"

print(medio_llamada)
print(dispositivo)
print(telefono)
print(telefono_persona)
print(saldo_celular)
print(saldo)
print(disponibilidad)
print(disponible_contacto)



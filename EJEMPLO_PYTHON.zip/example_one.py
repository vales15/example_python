"""
name = "Jesus maria gomez"
print("hello",name)

#ejemplo de casting (convertit una variabe de un tipo de dato a otro)
variable = 6
variable_uno = float(variable)
variable_dos = str(variable)

#sumar_datos = variable + variable_dos

#print(variable, variable_uno)
print(variable, variable_uno, variable_dos)
print(type(variable_dos))
print(type(variable_uno))
print(type(variable))
#print(sumar_datos)

"""

#tipos de datos
variable1 = "hola" #str(string)
variable2 = 20    #int(entero)
variable3 = 20.8   #float (decimal)
variable4 = 1j   #complex 
variable7 = True  #bool (logico)
variable5  = ["cantar","jugar","estudiar"]#list
variable6  = ("cantar","jugar","estudiar")#tupla
carro = {"color": "rojo", "velocidad" : 300, "modelo":"gtrr3"}#dict
#print(variable5)
#print(variable6)
#print(carro)
print(variable7)
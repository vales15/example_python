
number_one = 8
number_two = 5
#this is a comment of one line
#operacion de sumar los dos numeros 
"""
this is a multi-line comment
sumar =number_one + number_two

print(sumar)
"""

"""
this is rest
resta= number_one - number_two
print(resta)

"""
multiplicar = number_one * number_two
print(multiplicar)







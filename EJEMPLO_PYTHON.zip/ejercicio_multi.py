number_one = 8
number_two=5
"""
this is rest
resta= number_one - number_two
print(resta)

"""
multiplicar = number_one * number_two
print(multiplicar)

